#!/bin/sh

daemon_log=/software/script/log_dump.sh
script_name=$(basename "$0")
$daemon_log "$script_name: check extra video"

if pidof wget > /dev/null
then
	return
fi

for file in `ls /customer/video `       	
do
	is_file_in_use=0;
	for ini_file in `ls /customer/config/video_config*.ini`
	do
		if [ -f /customer/video"/"$file ] && [ "`grep "$file" "$ini_file"`" != "" ]
		then
			if ! pidof wget > /dev/null
			then
				is_file_in_use=1;	
			fi
		fi
	done	
				
	if find /customer/video_cache -maxdepth 1 -type f -name "*${file##*/}" 2>/dev/null  | grep -q .; then  
        is_file_in_use=1
    fi  
		
	if [ $is_file_in_use -eq 0 ];then
		if ! pidof wget > /dev/null
		then
			rm /customer/video"/"$file
		fi
	fi
done

if mountpoint -q "/mnt"; then 
	for file in `ls /mnt/video `       	
	do
		is_file_in_use=0;
		for ini_file in `ls /customer/config/video_config*.ini`
		do
			if [ -f /mnt/video"/"$file ] && [ "`grep "$file" "$ini_file"`" != "" ]
			then
				if ! pidof wget > /dev/null
				then
					is_file_in_use=1;
				fi
			fi
		done		
		
		if find /customer/video_cache -maxdepth 1 -type f -name "*${file##*/}" 2>/dev/null  | grep -q .; then  
			is_file_in_use=1
		fi  	
		
		if [ $is_file_in_use -eq 0 ];then
			if ! pidof wget > /dev/null
			then
				rm /mnt/video"/"$file
			fi
		fi
	done
fi