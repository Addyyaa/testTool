#!/bin/sh

daemon_log=/software/script/log_dump.sh
script_name=$(basename "$0")
$daemon_log "$script_name: restart ssplayer"

LOCKFILE=/tmp/video_player.lock
{

if [ "`grep off /tmp/screen_on_off`" != ""  ]; then
	echo "screen is off"
	exit 0
fi

echo high > /sys/class/gpio/gpio5/direction;

sleep 0.1

echo 50000 > /sys/class/pwm/pwmchip0/pwm0/duty_cycle; echo 500000 > /sys/class/pwm/pwmchip0/pwm0/duty_cycle;

sleep 0.1


echo "====================================restart video_player======================================================================"
cat /proc/mi_modules/mi_sys_mma/mma_heap_name0;
echo "===================================================================================================================================================="


if [ "`pidof video_player`" != "" ]; then

	/software/bin/kill_video_player &
	
	if [ "`pidof video_player`" != "" ]; then
		count=0
		while [ "$count" != "30"  ]
		do
			if [ "`pidof video_player`" == "" ]; then
				break
			fi
			count=$(($count+1))
			sleep 0.1
		done
		
		sleep 0.1
	fi
fi



echo high > /sys/class/gpio/gpio5/direction;

sleep 0.1

rmmod fbdev

sleep 1;

insmod /config/modules/4.9.84/fbdev.ko

sleep 1

#echo low > /sys/class/gpio/gpio5/direction; 

echo "====================================restart_video_player.sh after rm fb======================================================================"
cat /proc/mi_modules/mi_sys_mma/mma_heap_name0;


filename="/customer/config/config.ini"
section="screen"
key="luma_level"

value=$(awk -F "=" -v section="$section" -v key="$key" '$1 ~ /^\[/ && $1 ~ section {flag=1; next} flag==1 && $1 ~ /^\[/ {flag=0} flag==1 && $1 ~ key {print $2}' "$filename")
echo "luma_level = $value"
if [ "${value}" == "1" ]; then
	filename="/customer/config/luma_config.ini"
	section="luma_1"
	key="Luma"
	value=$(awk -F "=" -v section="$section" -v key="$key" '$1 ~ /^\[/ && $1 ~ section {flag=1; next} flag==1 && $1 ~ /^\[/ {flag=0} flag==1 && $1 ~ key {print $2}' "$filename")

elif [ "${value}" == "2" ]; then
	filename="/customer/config/luma_config.ini"
	section="luma_2"
	key="Luma"
	value=$(awk -F "=" -v section="$section" -v key="$key" '$1 ~ /^\[/ && $1 ~ section {flag=1; next} flag==1 && $1 ~ /^\[/ {flag=0} flag==1 && $1 ~ key {print $2}' "$filename")
elif [ "${value}" == "3" ]; then
	filename="/customer/config/luma_config.ini"
	section="luma_3"
	key="Luma"
	value=$(awk -F "=" -v section="$section" -v key="$key" '$1 ~ /^\[/ && $1 ~ section {flag=1; next} flag==1 && $1 ~ /^\[/ {flag=0} flag==1 && $1 ~ key {print $2}' "$filename")
fi

echo "luma = $value"

duty_cycle=$(($(($((100-$value))*500000))/100))
echo "duty_cycle = $duty_cycle"
#echo "$duty_cycle" > /sys/class/pwm/pwmchip0/pwm0/duty_cycle;


export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/lib:/config/lib:/customer/lib:/customer/bluetooth/lib:/software/lib:/software/bin:/software/bin/pintura/release/bin:upgrade/lib:/config/wifi:/software/qrcode
cd /software/bin/
./video_player &

sleep 0.2 
echo low > /sys/class/gpio/gpio5/direction; 
sleep 0.1
echo "$duty_cycle" > /sys/class/pwm/pwmchip0/pwm0/duty_cycle;
} 200>$LOCKFILE

