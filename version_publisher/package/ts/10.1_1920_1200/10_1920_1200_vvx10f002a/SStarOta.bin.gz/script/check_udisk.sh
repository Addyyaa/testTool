#!/bin/sh

daemon_log=/software/script/log_dump.sh
script_name=$(basename "$0")
$daemon_log "$script_name: check udisk"

curr_state=0
last_state=0

if mountpoint -q "/vendor/udisk_sda1"; then 
	last_state=1
else
	last_state=2
fi	

while [ 1 ]
    do
	
	if mountpoint -q "/vendor/udisk_sda1"; then 
		# mount -t vfat /dev/sda1 /vendor/udisk_sda1
		curr_state=1
	else
		# umount -v /vendor/udisk_sda1
		curr_state=2
	fi	

	if [ $curr_state -ne $last_state ];then
		if [ $curr_state -eq 1 ];then
			echo 'found udisk'
			echo 'udisk_found_tip' > /tmp/tip_status
		elif [ $curr_state -eq 2 ];then
			echo 'remove udisk'
			echo 'udisk_removed_tip' > /tmp/tip_status
			umount /vendor/udisk_sda1
		fi
	fi

	last_state=$curr_state

	sleep 1
done
