kill -9 $(pidof mymqtt) 
kill -9 $(pidof pintura)
kill -9 $(pidof video_player)
kill -9 $(pidof screen_driver)

cd /software/bin/
./mymqtt &

./screen_driver &

sleep 0.5
./video_player &

sleep 0.5
/software/bin/pintura/release/bin
./pintura &
