#!/bin/sh

daemon_log=/software/script/log_dump.sh
script_name=$(basename "$0")

echo 'off' > /tmp/screen_on_off
echo 50000 > /sys/class/pwm/pwmchip0/pwm0/duty_cycle; echo 500000 > /sys/class/pwm/pwmchip0/pwm0/duty_cycle;

sleep 0.01

if [ "`pidof pintura`" != "" ]
then
    $daemon_log "$script_name: pintura kill -2"
    kill -2 $(pidof pintura);

    count=0
    while [ "$count" != "30"  ]
    do
            if [ "`pidof pintura`" == "" ]; then
                    break
            fi
            count=$(($count+1))
            sleep 0.1
    done

    if [ "`pidof pintura`" != "" ]
    then
            $daemon_log "$script_name: pintura kill -9"
            kill -9 $(pidof pintura);
    fi
fi

sleep 0.01

if [ "`pidof video_player`" != "" ]
then
    $daemon_log "$script_name: video kill"
    cd /software/bin/
    ./kill_video_player &

    count=0
    while [ "$count" != "30"  ]
    do
            if [ "`pidof video_player`" == "" ]; then
                    break
            fi
            count=$(($count+1))
            sleep 0.1
    done

    if [ "`pidof video_player`" != "" ]
    then
            $daemon_log "$script_name: video kill -9"
            kill -9 $(pidof video_player);
    fi
fi

sleep 0.01

if [ "`pidof screen_driver`" != "" ]
then
    $daemon_log "$script_name: screen kill"
    cd /software/bin/
    ./kill_screen_driver &

    count=0
    while [ "$count" != "30"  ]
    do
            if [ "`pidof screen_driver`" == "" ]; then
                    break
            fi
            count=$(($count+1))
            sleep 0.1
    done

    if [ "`pidof screen_driver`" != "" ]; then
            $daemon_log "$script_name: screen kill -9"
            kill -9 $(pidof screen_driver);
    fi
fi



sleep 0.2

echo high > /sys/class/gpio/gpio5/direction;
echo low > /sys/class/gpio/gpio69/direction;
sleep 0.5;

# rmmod fbdev
# sleep 1;

# insmod /config/modules/4.9.84/fbdev.ko
# sleep 0.01;
