echo "boot load ko module..."
insmod /config/modules/4.9.84/cifs.ko
insmod /config/modules/4.9.84/nls_utf8.ko
insmod /config/modules/4.9.84/grace.ko
insmod /config/modules/4.9.84/sunrpc.ko
insmod /config/modules/4.9.84/lockd.ko
insmod /config/modules/4.9.84/nfs.ko
insmod /config/modules/4.9.84/nfsv2.ko
insmod /config/modules/4.9.84/fat.ko
insmod /config/modules/4.9.84/msdos.ko
insmod /config/modules/4.9.84/vfat.ko
insmod /config/modules/4.9.84/ntfs.ko
insmod /config/modules/4.9.84/usb-common.ko
insmod /config/modules/4.9.84/usbcore.ko
insmod /config/modules/4.9.84/ehci-hcd.ko
insmod /config/modules/4.9.84/usb-storage.ko
insmod /config/modules/4.9.84/usbhid.ko
insmod /config/modules/4.9.84/mdrv_crypto.ko
insmod /config/modules/4.9.84/soundcore.ko
insmod /config/modules/4.9.84/snd.ko
insmod /config/modules/4.9.84/snd-timer.ko
insmod /config/modules/4.9.84/snd-pcm.ko
#kernel_mod_list
insmod /config/modules/4.9.84/mhal.ko
#misc_mod_list
insmod /config/modules/4.9.84/mi_common.ko
insmod /config/modules/4.9.84/mi_sys.ko cmdQBufSize=128 logBufSize=0
insmod /config/modules/4.9.84/mi_gfx.ko
insmod /config/modules/4.9.84/mi_divp.ko
insmod /config/modules/4.9.84/mi_vdec.ko
insmod /config/modules/4.9.84/mi_ai.ko
insmod /config/modules/4.9.84/mi_ao.ko
insmod /config/modules/4.9.84/mi_disp.ko
insmod /config/modules/4.9.84/mi_alsa.ko
insmod /config/modules/4.9.84/mi_venc.ko
insmod /config/modules/4.9.84/mi_panel.ko

#mi module
major=`cat /proc/devices | busybox awk "\\$2==\""mi_poll"\" {print \\$1}"`
busybox mknod /dev/mi_poll c $major 0
insmod /config/modules/4.9.84/fbdev.ko

#misc_mod_list_late
mdev -s
export TERM=vt102
export TERMINFO=/config/terminfo
echo /customer/pq.ini  0x148 > /sys/class/mstar/mdisp/pq

#PM_LED0
echo 69 > /sys/class/gpio/export
echo high > /sys/class/gpio/gpio69/direction
#wifi power on
#echo 73 > /sys/class/gpio/export
#echo low > /sys/class/gpio/gpio73/direction
#wifi enable
#echo 14 > /sys/class/gpio/export
#echo low > /sys/class/gpio/gpio14/direction
#sleep 0.5
#echo high > /sys/class/gpio/gpio14/direction
#reset gpio, cat /sys/class/gpio/gpio71/value 1:normal 0: press
echo 71 > /sys/class/gpio/export
echo 5 > /sys/class/gpio/export
echo low > /sys/class/gpio/gpio5/direction

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/lib:/config/lib:/customer/lib:/customer/bluetooth/lib:/software/lib:/upgrade/lib:/config/wifi:/software/qrcode

cd /sys/class/pwm/pwmchip0/
echo 0 > export
cd pwm0/
echo 500000 > period
echo 1 > enable
sleep 0.5

echo "boot init software..."
cd /software/script/
./software_init.sh
sleep 0.5

echo "boot screen driver"
cd /software/bin/
./screen_driver &

echo "boot video player"
cd /software/bin/
./video_player &

echo "boot pintura"
cd /software/bin/pintura/release/bin
./pintura &

echo "boot daemo process"
cd /software/script/
./daemon.sh &

echo "boot recovery process"
cd /upgrade/recovery/
./check.sh &