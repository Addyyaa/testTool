#!/bin/sh

daemon_log=/software/script/log_dump.sh
script_name=$(basename "$0")
$daemon_log "$script_name: check usb"

while [ 1 ]
    do
	if [ -e  /customer/picture/black.jpg ];
	then
		if [ -e /vendor/udisk_sda* ];
		then 
			echo high > /sys/class/gpio/gpio69/direction;
			sleep 1
			echo low > /sys/class/gpio/gpio69/direction;			
		else
			if [ `cat /sys/devices/gpiochip0/gpio/gpio5/value | grep 0` ];
			then
				echo high > /sys/class/gpio/gpio69/direction;
			else
				echo low > /sys/class/gpio/gpio69/direction;
			fi
		fi
		sleep 1
	else
		if [ `cat /sys/devices/gpiochip0/gpio/gpio5/value | grep 0` ];
		then
			echo high > /sys/class/gpio/gpio69/direction;
		else
			echo low > /sys/class/gpio/gpio69/direction;
		fi
		exit 0;
	fi	
done
