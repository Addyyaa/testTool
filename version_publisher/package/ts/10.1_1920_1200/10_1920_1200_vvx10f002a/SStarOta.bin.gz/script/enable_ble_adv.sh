#!/bin/sh

daemon_log=/software/script/log_dump.sh
script_name=$(basename "$0")
$daemon_log "$script_name: enable ble adv"

cd /customer/bluetooth/bin
./hciconfig hci0 leadv

