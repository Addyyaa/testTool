#!/bin/sh

daemon_log=/software/script/log_dump.sh
script_name=$(basename "$0")
$daemon_log "$script_name: restore factory setting"

kill -9 $(pgrep -f network_check.sh)
kill -9 $(pgrep -f daemon.sh)
kill -9 $(pidof mymqtt)
kill -9 $(pidof rtl_gatts);
kill -9 $(pidof uart_main);
/software/bin/kill_video_player
sleep 0.5

echo '' > /upgrade/tfilelist; 
echo '' > /upgrade/xfilelist;
if [ -e /tmp/software_init_finish ]; then
	rm /tmp/software_init_finish;
fi

#tip update
echo 'upgrading' > /tmp/rst_status
sleep 1

#clear temp file
rm /tmp/pairing_status;

#reset user config
cp -rf /software/etc/wpa_supplicant.conf /appconfigs/wpa_supplicant.conf

#clear in user data(xp version is will config.ini_bak to config.ini at start time software_init.sh)
rm -rf /customer/picture/*
rm -rf /customer/picture_cache/*
rm -rf /customer/video/*
rm -rf /customer/video_cache/*
rm -rf /customer/gift/*
rm -rf /customer/gift_cache/*

#clear tf user data
if [ -e /mnt/picture/ ]; then
	rm -rf /mnt/picture/*
fi

if [ -e /mnt/video/ ]; then
	rm -rf /mnt/video/*
fi

if [ -e /mnt/syncall.flag ]; then
	rm -rf /mnt/syncall.flag
fi

#update resetting data, It could be an upgrade or a downgrade
cp /software/script/rst_downgrading_patch.sh /upgrade/

#update software data
$daemon_log "$script_name: restore factory startting"

rm -rf /software/*
(tar tvf /upgrade/restore/SStarOta.bin.gz) > /upgrade/tfilelist
(tar xvf /upgrade/restore/SStarOta.bin.gz -C /software/) > /upgrade/xfilelist
sync

#update resetting data, It could be an upgrade or a downgra
/upgrade/rst_downgrading_patch.sh;
rm -rf /upgrade/rst_downgrading_patch.sh

#tip update
echo 'success' > /tmp/rst_status
sleep 3

echo high > /sys/class/gpio/gpio5/direction;
sleep 0.1

echo 50000 > /sys/class/pwm/pwmchip0/pwm0/duty_cycle; 
echo 500000 > /sys/class/pwm/pwmchip0/pwm0/duty_cycle;
sleep 0.01

#reset gpio 48, reset screen
if [ ! -e /sys/class/gpio/gpio48/value ]
then				
	echo 48 > /sys/class/gpio/export				
fi
if [ -e /sys/class/gpio/gpio48/value ]
then
	echo low > /sys/class/gpio/gpio48/direction
fi

rm -rvf /customer/logs/*
reboot
#sleep 0.5
#echo low > /sys/class/gpio/gpio5/direction;
#sleep 0.2;
#echo 0 > /sys/class/pwm/pwmchip0/pwm0/duty_cycle;
#sleep 0.2;
#cd /upgrade/
#./otaunpack -x /upgrade/restore/SStarOta.bin.gz -p /upgrade/upgrade.jpg

