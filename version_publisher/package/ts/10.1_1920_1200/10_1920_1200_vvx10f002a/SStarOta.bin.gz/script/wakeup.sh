#!/bin/sh

daemon_log=/software/script/log_dump.sh
script_name=$(basename "$0")
$daemon_log "$script_name: wakeup"

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/lib:/config/lib:/customer/lib:/customer/bluetooth/lib:/software/bin/pintura/release/bin:/software/lib:/upgrade/lib:/config/wifi:/software/qrcode
daemon_log=/software/script/log_dump.sh
script_name=$(basename "$0")

rm     /tmp/show_video_player
touch  /tmp/show_video_logo

count=0
while [ "$count" != "30"  ]
do
        if [ "`pgrep -f sleep.sh`" == "" ]; then
                break
        fi
        count=$(($count+1))
        sleep 0.1
done

echo low > /sys/class/gpio/gpio5/direction;
echo high > /sys/class/gpio/gpio69/direction;
sleep 1

if [ "`pidof screen_driver`" == "" ]
then
	$daemon_log "$script_name:screen reboot 1"
        cd /software/bin/
        ./screen_driver &

        count=0
        while [ "$count" != "30"  ]
        do
                if [ "`pidof screen_driver`" != "" ]; then
                        break
                fi
                count=$(($count+1))
                sleep 0.1
        done

        if [ "`pidof screen_driver`" == "" ]
        then
                $daemon_log "$script_name:screen reboot 2"
                cd /software/bin/
                ./screen_driver &
        fi
fi

sleep 0.2;

if [ "`pidof pintura`" == "" ]
then
        $daemon_log "$script_name:pintura reboot 1"
        cd /software/bin/pintura/release/bin/
        ./pintura &

        count=0
        while [ "$count" != "30"  ]
        do
                if [ "`pidof pintura`" != "" ]; then
                        break
                fi
                count=$(($count+1))
                sleep 0.1
        done

        if [ "`pidof pintura`" == "" ]
        then
                $daemon_log "$script_name:pintura reboot 2"
                cd /software/bin/pintura/release/bin/
                ./pintura &
        fi
fi

sleep 2;

if [ "`pidof video_player`" == "" ]
then
        $daemon_log "$script_name:video_player reboot 1"
        cd /software/bin/
        ./video_player &

        count=0
        while [ "$count" != "30"  ]
        do
                if [ "`pidof video_player`" != "" ]; then
                        break
                fi
                count=$(($count+1))
                sleep 0.1
        done

        if [ "`pidof video_player`" == "" ]
        then
                $daemon_log "$script_name:video_player reboot 2"
                cd /software/bin/
                ./video_player &
        fi
fi

sleep 0.2;

echo 'on' > /tmp/screen_on_off
