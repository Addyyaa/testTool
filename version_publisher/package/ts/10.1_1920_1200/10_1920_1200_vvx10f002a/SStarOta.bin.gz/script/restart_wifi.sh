#!/bin/sh

daemon_log=/software/script/log_dump.sh
script_name=$(basename "$0")
$daemon_log "$script_name: restart wifi"

kill -9 $(pidof udhcpc) >/dev/null 2>&1
kill -9 $(pidof wpa_supplicant) >/dev/null 2>&1
ip addr flush dev wlan0
#ip route flush table all
ifconfig wlan0 down
ifconfig wlan0 up

kill -9 $(pidof mymqtt)

cd /config/wifi/
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/local/lib:/lib:/config/wifi

./wpa_supplicant -Dnl80211 -i wlan0 -c /appconfigs/wpa_supplicant.conf >/dev/null 2>&1 &
udhcpc -q -i wlan0 -s /etc/init.d/udhcpc.script >/dev/null 2>&1 &
echo 0 > /proc/net/$(ls /proc/net/ | grep rtl)/log_level
