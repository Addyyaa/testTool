#!/bin/sh

daemon_log=/software/script/log_dump.sh
script_name=$(basename "$0")
$daemon_log "$script_name: stop bluetooth"

is_bluetooth_on=0
if [ `pidof rtl_gatts` ]; then
	is_bluetooth_on=1
	kill -9 $(pidof rtl_gatts)
fi

cd /customer/bluetooth/bin
./hciconfig hci0 down

if [ "$is_bluetooth_on" -eq "1" ]; then
	echo "bluetooth_off" > /tmp/tip_status
fi



