#!/bin/sh

daemon_log=/software/script/log_dump.sh
script_name=$(basename "$0")
$daemon_log "$script_name: upgrade"

kill -9 $(pgrep -f network_check.sh)
kill -9 $(pgrep -f daemon.sh)
kill -9 $(pidof mymqtt)
kill -9 $(pidof rtl_gatts);
kill -9 $(pidof uart_main);
/software/bin/kill_video_player
sleep 0.5

#tip update
echo 'upgrading' > /tmp/ota_status

#update factory package
if [ -e /tmp/update_reset ] && [ -e /upgrade/SStarOta.bin.gz ]; then
	cp /upgrade/SStarOta.bin.gz /upgrade/restore/SStarOta.bin.gz
fi

#update downgrading data, It could be an upgrade or a downgrade
cp /software/script/ota_downgrading_patch.sh /upgrade/

#update software data
rm -rf /software/*
(tar tvf /upgrade/SStarOta.bin.gz) > /upgrade/tfilelist
(tar xvf /upgrade/SStarOta.bin.gz -C /software/) > /upgrade/xfilelist
sync

#update downgrading data, It could be an upgrade or a downgra
/upgrade/ota_downgrading_patch.sh;
rm -rf /upgrade/ota_downgrading_patch.sh

#tip update
echo 'success' > /tmp/ota_status

sleep 3

echo 50000 > /sys/class/pwm/pwmchip0/pwm0/duty_cycle; 
echo 500000 > /sys/class/pwm/pwmchip0/pwm0/duty_cycle;
sleep 0.2

echo high > /sys/class/gpio/gpio5/direction;

#reset gpio 48, reset screen
if [ ! -e /sys/class/gpio/gpio48/value ]
then				
	echo 48 > /sys/class/gpio/export				
fi
if [ -e /sys/class/gpio/gpio48/value ]
then
	echo low > /sys/class/gpio/gpio48/direction
fi

cp /software/config/log.* /customer/config/
rm -rvf /customer/logs/*
reboot
#cd /upgrade/
#./otaunpack -x SStarOta.bin.gz -p upgrade.jpg