#!/bin/sh

daemon_log=/software/script/log_dump.sh
script_name=$(basename "$0")
$daemon_log "$script_name: software init"

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/lib:/config/lib:/customer/lib:/customer/bluetooth/lib:/software/lib:/upgrade/lib:/config/wifi:/software/qrcode

find /config -type f -name "coredump.process_*.gz" -exec rm -f {} \; 2>/dev/null

# params
echo "software init reboot"
need_reboot=0
need_update_bootargs=0
if ! /etc/fw_printenv | grep -q 'highres=on' ; then	
	need_reboot=1
	need_update_bootargs=1
	echo "need updte to reboot 1"
fi

if /etc/fw_printenv | grep -q 'sz=0x2400000' ; then	
	need_reboot=1
	need_update_bootargs=1
	echo "need updte to reboot 2"
fi

if  [ "$need_update_bootargs" == "1" ]; then
	echo "/dev/mtd6 0x00000 0x1000 0x40000 2" > /etc/fw_env.config
	echo "/dev/mtd7 0x00000 0x1000 0x40000 2" >> /etc/fw_env.config
	/etc/fw_setenv bootargs 'console=ttyS0,115200 ubi.mtd=UBI,4096 root=ubi:rootfs rw rootfstype=ubifs init=/linuxrc rootwait=1 LX_MEM=0x7f00000 mma_heap=mma_heap_name0,miu=0,sz=0x2a00000 mma_memblock_remove=1 highres=on mmap_reserved=fb,miu=0,sz=0x600000,max_start_off=0x7900000,max_end_off=0x7F00000 mtdparts=nand0:768k@2560k(IPL0),768k(IPL1),768k(IPL_CUST0),768k(IPL_CUST1),1536k(UBOOT0),1536k(UBOOT1),256k(ENV),256k(ENV1),0x40000(KEY_CUST),0x80000(LOGO),0xA00000(KERNEL),0xA00000(RECOVERY),-(UBI)'	
fi

# ko driver
echo "software init miko"
need_update_mi_ko=0

cd /config/modules/4.9.84/
if (! grep -q $(md5sum mhal.ko) /software/software_md5) || (! grep -q $(md5sum mi_vdec.ko) /software/software_md5); then
	need_update_mi_ko=1
fi

cd /software/etc/
if [ $need_update_mi_ko -eq 1 ] && [ -e mi_ko.tar.gz ]; then
	if grep -q $(md5sum mi_ko.tar.gz) /software/software_md5; then		
		tar xvf mi_ko.tar.gz -C /config/modules/4.9.84/
		if [ $? -eq 0 ]; then
			need_reboot=1
			touch /customer/update_mi_ko_success
			sync;			
		fi
	fi 
fi

# hostapd
echo "software init hostapd"
if [ ! -e /config/wifi/hostapd.conf ] && [ -e /software/etc/hostapd.conf ]; then
	cp -rf /software/etc/hostapd.conf /config/wifi/
fi

if [ ! -e /config/wifi/udhcpd.conf ] && [ -e /software/etc/udhcpd.conf ]; then
	cp -rf /software/etc/udhcpd.conf /config/wifi/
fi

NEW_INTERFACE="wlan1"
CONFIG_FILE="/config/wifi/hostapd.conf"
sed -i "s/^interface=.*/interface=$NEW_INTERFACE/" "$CONFIG_FILE"
if ! grep -q "^interface=" "$CONFIG_FILE"; then
    echo "interface=$NEW_INTERFACE" >> "$CONFIG_FILE"
fi

section="screen"
key="deviceId"
VERSION_PATH="/customer/screenId.ini"
VERSION_NUMBER=$(awk -F "=" -v section="$section" -v key="$key" '$1 ~ /^\[/ && $1 ~ section {flag=1; next} flag==1 && $1 ~ /^\[/ {flag=0} flag==1 && $1 ~ key {print $2}' "$VERSION_PATH")
echo "VERSION_NUMBER:${VERSION_NUMBER}"

CONFIG_FILE="/config/wifi/hostapd.conf"
sed -i "s/^ssid=.*/ssid=$VERSION_NUMBER/" "$CONFIG_FILE"
if ! grep -q "^ssid=" "$CONFIG_FILE"; then
    echo "ssid=$VERSION_NUMBER" >> "$CONFIG_FILE"
fi

# frame buffer
echo "software init fbdev"
filename="/config/fbdev.ini"
section="FB_DEVICE"
key="FB_BUFFER_LEN"
value=$(awk -F "=" -v section="$section" -v key="$key" '$1 ~ /^\[/ && $1 ~ section {flag=1; next} flag==1 && $1 ~ /^\[/ {flag=0} flag==1 && $1 ~ key {print $2}' "$filename")
trimmed_value="${value#"${value%%[![:space:]]*}"}"  
trimmed_value="${trimmed_value%"${trimmed_value##*[![:space:]]}"}" 
if [ "${trimmed_value}" == "28000" ];then	
	need_reboot=1
	cp $filename /customer/fbdev.ini_bak
	TEMP_FILE=$(mktemp)  
	
	awk -v new_value=9000 '  
	BEGIN { found = 0 }  
	/^[[:space:]]*FB_BUFFER_LEN[[:space:]]*=[[:space:]]*28000[[:space:]]*/ {  
		$0 = gensub(/28000/, new_value, "g", $0)  
		found = 1  
	}  
	{ print }  
	END {  
		if (!found) {  
			print "FB_BUFFER_LEN was not found with value 28000 or the format was unexpected." > "/dev/stderr"  
		}  
	}  
	' "$filename" > "$TEMP_FILE" && mv "$TEMP_FILE" "$filename"  	
	if [ ! -s $filename ] && [ -s /customer/fbdev.ini_bak ]; then
		cp /customer/fbdev.ini_bak  $filename
	fi
fi

if [ "${trimmed_value}" == "18000" ];then	
	need_reboot=1
	cp $filename /customer/fbdev.ini_bak
	TEMP_FILE=$(mktemp)  
	
	awk -v new_value=9000 '  
	BEGIN { found = 0 }  
	/^[[:space:]]*FB_BUFFER_LEN[[:space:]]*=[[:space:]]*18000[[:space:]]*/ {  
		$0 = gensub(/18000/, new_value, "g", $0)  
		found = 1  
	}  
	{ print }  
	END {  
		if (!found) {  
			print "FB_BUFFER_LEN was not found with value 18000 or the format was unexpected." > "/dev/stderr"  
		}  
	}  
	' "$filename" > "$TEMP_FILE" && mv "$TEMP_FILE" "$filename"  	
	if [ ! -s $filename ] && [ -s /customer/fbdev.ini_bak ]; then
		cp /customer/fbdev.ini_bak  $filename
	fi
fi

if [ "$need_reboot" == "1" ]; then	
	sync
	
	echo high > /sys/class/gpio/gpio5/direction;
	sleep 0.1
	if [ ! -e /sys/class/gpio/gpio48/value ]
	then				
		echo 48 > /sys/class/gpio/export				
	fi
	if [ -e /sys/class/gpio/gpio48/value ]
	then
		echo low > /sys/class/gpio/gpio48/direction
	fi
	sleep 0.1
	reboot
fi

echo "software init path"
mount -t vfat /dev/mmcblk0p1 /mnt

mkdir -p /customer/picture/
mkdir -p /customer/picture_cache/
mkdir -p /customer/video/
mkdir -p /customer/video_cache/
mkdir -p /customer/gift/
mkdir -p /customer/gift_cache/
mkdir -p /customer/logs/

if mountpoint -q "/mnt"; then 
	mkdir -p /mnt/picture/
	mkdir -p /mnt/video/
	if [ -s /mnt/init.sh ]
	then
		chmod +x /mnt/init.sh
		/mnt/init.sh &
	else
		if [ -s /customer/config/mnt_config.ini_bak ]
		then
			mv -f /customer/config/mnt_config.ini_bak /customer/config/config.ini 
		fi
		
		if [ -s /customer/config/mnt_video_config.ini_bak ]
		then
			mv -f /customer/config/mnt_video_config.ini_bak /customer/config/video_config.ini 
		fi
	fi
else
	if [ -s /customer/config/mnt_config.ini_bak ]
	then
		mv -f /customer/config/mnt_config.ini_bak /customer/config/config.ini 
	fi

	if [ -s /customer/config/mnt_video_config.ini_bak ]
	then
		mv -f /customer/config/mnt_video_config.ini_bak /customer/config/video_config.ini 
	fi
fi

## media cache
rm -rf /customer/picture_cache_trash_* &
rm -rf /customer/video_cache_trash_* &
	
if [ -e /mnt/picture/ ]; then
	rm -rf /mnt/picture_trash_* &
fi
if [ -e /mnt/video/ ]; then
	rm -rf /mnt/video_trash_* &
fi

rm -rf /customer/picture_trash_* &
rm -rf /customer/video_trash_* &

if [ -f /software/lib/ln.sh ]; then
	cd /software/lib/
	./ln.sh &
fi

if [ -f /customer/bluetooth/lib/ln.sh ]; then
	cd /customer/bluetooth/lib/
	./ln.sh &
fi

## ota cache
if [ -e /upgrade/SStarOta.bin.gz ]
then 
	(rm /upgrade/SStarOta.bin.gz) 
fi;

if [ -e /upgrade/tfilelist ]
then 
	(rm /upgrade/tfilelist) 
fi;

if [ -e /upgrade/xfilelist ]
then 
	(rm /upgrade/xfilelist) 
fi;

if [ -e /upgrade/ota_md5 ]
then 
	(rm /upgrade/ota_md5) 
fi;

if [ -e /upgrade/ota_url ]
then 
	(rm /upgrade/ota_url) 
fi;

##
echo "software init timezone"

need_update_zone_info=0
if [ ! -e /usr/share/zoneinfo/ ]; then	
	need_update_zone_info=1;
elif [ ! -e /customer/update_zone_info_success ]; then
	need_update_zone_info=1;
	rm -rf /usr/share/zoneinfo/*
fi

cd /software/etc/
if [ $need_update_zone_info -eq 1 ] && [ -e zoneinfo.tar.gz ]; then
	if grep -q $(md5sum zoneinfo.tar.gz) /software/software_md5; then
		mkdir -p /usr/share/zoneinfo/
		tar xvf zoneinfo.tar.gz -C /usr/share/zoneinfo/
		if [ $? -eq 0 ]; then
			touch /customer/update_zone_info_success
			sync;			
		fi
	fi 
fi

# init res
cd /software/etc/
if [ ! -e /customer/number_image_dir/1.png ]; then	
	mkdir -p /customer/number_image_dir/
	tar xvf number_image_dir.tar -C /customer/
fi

# init config
if [ -e /software/config/ ] && [ ! -e /customer/config ]; then	
	cp -rf /software/config/ /customer/	
fi;

if [ -e /software/config/screenId.ini ] && [ ! -e /customer/screenId.ini ]; then	
	cp -rf /software/config/screenId.ini /customer/	
fi;

if [ -e /software/etc/wpa_supplicant.conf ] && [ ! -e /appconfigs/wpa_supplicant.conf ]; then	
	cp -rf /software/etc/wpa_supplicant.conf /appconfigs/
fi;

# init recovery
if [ -e /software/etc/recovery ] && [ ! -e /upgrade/recovery ]; then	
	cp -rf /software/etc/recovery /upgrade/
fi;

if [ ! -e /upgrade/recovery/check.sh ]; then	
	cp -rf /software/etc/recovery/check.sh /upgrade/recovery/
fi;

if [ ! -e /upgrade/recovery/ota_downgrading_patch.sh ]; then	
	cp -rf /software/etc/recovery/ota_downgrading_patch.sh /upgrade/recovery/
fi;

if [ ! -e /upgrade/recovery/upgrade.sh ]; then	
	cp -rf /software/etc/recovery/upgrade.sh /upgrade/recovery/
fi;

chmod +x /upgrade/recovery/*.sh

##
echo "software init dns"
filename="/software/local.ini"
section="local"
key="local"

cd /software/config/
value=$(awk -F "=" -v section="$section" -v key="$key" '$1 ~ /^\[/ && $1 ~ section {flag=1; next} flag==1 && $1 ~ /^\[/ {flag=0} flag==1 && $1 ~ key {print $2}' "$filename")
if [ "${value}" == "2" ]; then
	if [ -e resolv.conf ]; then
		if ! diff resolv.conf /customer/resolv.conf >/dev/null; then
			if  grep -q $(md5sum resolv.conf) /software/software_md5; then
				cp resolv.conf /customer/
			fi
		fi
	fi;
elif [ "${value}" == "1" ]; then
	if [ -e resolv.conf_cn ]; then
		if ! diff resolv.conf_cn /customer/resolv.conf >/dev/null; then
			if  grep -q $(md5sum resolv.conf_cn) /software/software_md5; then
				cp resolv.conf_cn /customer/resolv.conf
			fi
		fi
	fi;
fi

# binary exec
echo "software init bin"
cd /software/bin/
chmod +x *
chmod +x /software/bin/pintura/release/bin/pintura

# other
cd /software/etc/
if [ -e chagall.bin ]; then	
	if ! diff chagall.bin /config/vdec_fw/normal/chagall.bin >/dev/null; then
		if grep -q $(md5sum chagall.bin) software_md5; then
			cp chagall.bin /config/vdec_fw/normal/chagall.bin	
		fi
	fi
fi;

echo "software init status"
echo '' > /tmp/ota_status
echo '' > /tmp/rst_status
echo '' > /tmp/tip_status
echo 'on' > /tmp/screen_on_off

#wifi
echo "boot wifi..."
rm /config/coredump.process_*
/config/wifi/ssw01bInit.sh
/software/script/restart_wifi.sh &

#dbus + bluetoothd
echo "boot bluetoothd..."
mkdir /var/run
mount tmpfs /var/run -t tmpfs
ln -s /customer/bluetooth/bluez_build/dbus/var/run/dbus /var/run/dbus
rm /customer/bluetooth/bluez_build/dbus/var/run/dbus/pid
insmod /customer/bluetooth/rtk_btusb.ko
cd /customer/bluetooth/bin
./dbus-daemon --system &
sleep 1
./bluetoothd -n -C &

## exec
sleep 1
cd /software/script/
./check_usb.sh &
./check_udisk.sh &
./check_sdcard.sh &
./restart_bluetooth.sh &
./restart_hostapd.sh &

cd /software/bin/
./uart_main &
./misc_driver &

#schedule sleep wakeup
# mkdir -p /var/spool/cron/crontabs
# mkdir -p /etc/crontabs/
# if [ -e /etc/crontabs/root ]; then
# 	cp -p /etc/crontabs/root /var/spool/cron/crontabs
# 	chmod 777 /var/spool/cron/crontabs/root
# fi
# crond

sync

touch /tmp/software_init_finish
