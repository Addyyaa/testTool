#!/bin/sh

daemon_log=/software/script/log_dump.sh
script_name=$(basename "$0")
$daemon_log "$script_name: check sdcard"

while [ 1 ]
    do
	
	if [ -e /dev/mmcblk0p1 ]; then
		if ! mountpoint -q "/mnt"; then 
			mount -t vfat /dev/mmcblk0p1 /mnt
			if mountpoint -q "/mnt"; then 
				mkdir -p /mnt/picture/
				mkdir -p /mnt/video/
				echo 'sdcard_found_tip' > /tmp/tip_status
				if [ -e /mnt/after_mount.sh ]
				then
					cp /mnt/after_mount.sh /software/after_mount.sh
					chmod +x /software/after_mount.sh
					/software/after_mount.sh &
				fi
				
				if [ -e /mnt/after_unmount.sh ]
				then
					cp /mnt/after_unmount.sh /software/after_unmount.sh
				else
					if [ -e /software/after_unmount.sh ]
					then
						rm /software/after_unmount.sh
					fi
				fi
			fi
		fi
	else
		if mountpoint -q "/mnt"; then 			
			if [ -e /software/after_unmount.sh ]
			then
				chmod +x /software/after_unmount.sh
				/software/after_unmount.sh &
			fi
			umount -v /mnt
			echo 'sdcard_removed_tip' > /tmp/tip_status
		fi
	fi	

	sleep 0.3	
done
