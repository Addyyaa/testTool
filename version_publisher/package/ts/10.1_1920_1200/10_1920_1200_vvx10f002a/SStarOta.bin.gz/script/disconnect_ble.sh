#!/bin/sh

daemon_log=/software/script/log_dump.sh
script_name=$(basename "$0")

cd /customer/bluetooth/bin
handle=$(./hcitool con | grep -o 'handle [0-9]\+' | awk '{print $2}')
if [ "$handle" != "" ]
then
./hcitool ledc $handle
./hciconfig hci0 leadv
else
$daemon_log "$script_name: restart bluetooth"
/software/script/restart_bluetooth.sh notip &
fi
