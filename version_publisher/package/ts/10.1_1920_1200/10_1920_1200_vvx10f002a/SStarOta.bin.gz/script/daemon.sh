#!/bin/sh

daemon_log=/software/script/log_dump.sh
script_name=$(basename "$0")
$daemon_log "$script_name: daemon"

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/lib:/config/lib:/customer/lib:/customer/bluetooth/lib:/software/lib:/software/bin:/software/bin/pintura/release/bin:upgrade/lib:/config/wifi:/software/qrcode
script_name=$(basename "$0")

wlanDownCount=0
pinturaUIDownCount=0
videoPlayerDownCount=0
pairing_status='';
ble_state=0;
ble_state_update_time=0;
ble_state_count=0
ble_adv_count=0
daemon_log=/software/script/log_dump.sh

grace_reboot() {
	$daemon_log "$1, reboot"
	echo high > /sys/class/gpio/gpio5/direction;
	sleep 0.1
	if [ ! -e /sys/class/gpio/gpio48/value ]
	then				
		echo 48 > /sys/class/gpio/export				
	fi
	if [ -e /sys/class/gpio/gpio48/value ]
	then
		echo low > /sys/class/gpio/gpio48/direction
	fi
	sleep 0.1
	reboot
}

while [ 1 ]
    do
	find /config -type f -name "coredump.process_*.gz" -exec rm -f {} \; 2>/dev/null

	if [ "`ifconfig wlan0 | grep 'inet addr:'`" == "" ] && ([ ! -e /tmp/pairing_status ] || [ `cat /tmp/pairing_status | grep success` ]);
	then
		wlanDownCount=$(($wlanDownCount+1))
		if [ $wlanDownCount -eq 120 ]
		then
			wlanDownCount=0
			
			if [ -e /tmp/pairing_status ] && [ `cat /tmp/pairing_status | grep success` ] && [ ! -e /tmp/net_unstable_tip_flag ]; then
				touch /tmp/net_unstable_tip_flag
				echo "network_instability_tip" > /tmp/tip_status
			fi

			/software/script/restart_wifi.sh &
		fi
	fi
	
	ble_need_restart=0
	if [ -e /tmp/blestate ] && [ "`pidof rtl_gatts`" != "" ]
	then		
		tmp_ble_state=$(cat /tmp/blestate)
		tmp_ble_state_update_time=$(stat -c %Y /tmp/blestate)
		if [ "$tmp_ble_state" != "" ] && [ "$tmp_ble_state" != "2" ] && [ "$tmp_ble_state" != "0" ] && [ "$tmp_ble_state" == "$ble_state" ] && [ "$tmp_ble_state_update_time" == "$ble_state_update_time" ]
		then
			ble_state_count=$(($ble_state_count+1))
			if [ "$tmp_ble_state" == "5" ]
			then
				if [ "$ble_state_count" == "90" ]
				then
					ble_need_restart=1
				fi
			else
				if [ "$ble_state_count" == "10" ]
				then
					ble_need_restart=1
				fi
			fi
		else
			ble_state=$tmp_ble_state
			ble_state_update_time=$tmp_ble_state_update_time
			ble_state_count=0;
		fi
		
		if [ "`pidof rtl_gatts`" != "" ] && [ "$tmp_ble_state" == "2" ]
		then
			ble_adv_count=$(($ble_adv_count+1))
			if [ "$ble_adv_count" == "3" ]
			then
				ble_adv_count=0
				if [ "`pgrep -f enable_ble_adv.sh`" == "" ]; then
					/software/script/enable_ble_adv.sh &				
				fi
			fi
		else
			ble_adv_count=0;
		fi
	fi
	
	if [ "$ble_need_restart" == "1"  ]
	then
		ble_state_count=0;
		echo > /tmp/blestate
		if [ "`pidof rtl_gatts`" == "" ]
		then			
			/software/script/restart_bluetooth.sh notip &
		else
			/software/script/disconnect_ble.sh &
		fi
	fi

	# watch media and ui if sceeen is on, 
	if [ "`grep off /tmp/screen_on_off`" == ""  ] && [ -e /tmp/software_init_finish ]
    then
		if [ "`pidof screen_driver`" == "" ]
		then
			$daemon_log "$script_name: screen reboot"
			cd /software/bin/
			./screen_driver &
		fi

		if [ "`pidof pintura`" == "" ]
		then
			$daemon_log "$script_name: pintura reboot"
			cd /software/bin/pintura/release/bin
			./pintura &
		fi

		if [ "`pidof video_player`" == "" ]
		then
			$daemon_log "$script_name: video reboot"
			cd /software/bin/
			./video_player &
		fi
	fi

	if [ "`pidof misc_driver`" == "" ]
	then
		$daemon_log "$script_name: misc reboot"
		cd /software/bin/
		./misc_driver  &
	fi

	if [ "`pidof web`" == "" ]
	then
		$daemon_log "$script_name: web reboot"
		cd /software/bin/
		./web &
	fi

	# watch mqtt
    if [ "`pidof mymqtt`" == "" ]
    then
		if [ -e /tmp/server_connected ]
		then
			rm /tmp/server_connected
		fi

		if [ "`ifconfig wlan0 | grep 'inet addr:'`" != "" ] && [ `cat /sys/class/net/wlan0/operstate | grep up` ]
		then
			$daemon_log "$script_name: mqtt reboot"
			/software/bin/mymqtt &
			kill -9 $(pidof ntpd)			

			filename="/software/local.ini"
			section="local"
			key="local"
			value=$(awk -F "=" -v section="$section" -v key="$key" '$1 ~ /^\[/ && $1 ~ section {flag=1; next} flag==1 && $1 ~ /^\[/ {flag=0} flag==1 && $1 ~ key {print $2}' "$filename")
			if [ "${value}" == "1" ]; then
				echo "ntpd -p ntp.aliyun.com"
				ntpd -p ntp.aliyun.com &
			else
				echo "ntpd -p time.nist.gov"
				ntpd -p time.nist.gov &
			fi
		fi
    fi

	no_wakeup_count=$(dmesg | grep 'no wakeup event' | wc -l)
	if [ "$no_wakeup_count" -gt 0 ]; then 
		grace_reboot "dmesg catch no wakeup event"
	fi
	
	if [ "`pidof video_player`" != "" ]; then		
		video_player_state=$(top -n1 | grep video_player | grep -v grep | grep -v tail  | grep -v cat | awk {'print $4'})
		if [ "$video_player_state" == "D" ]
		then
			videoPlayerDownCount=$(($videoPlayerDownCount+1))
			if [ $videoPlayerDownCount -eq 20 ]
			then
				videoPlayerDownCount=0;
				grace_reboot "top -n1 catch video_player D status over 20 times"
			fi
		else
			videoPlayerDownCount=0;
		fi
	fi

	if [ "`pidof pintura`" != "" ]; then		
		pintura_ui_state=$(top -n1 | grep pintura | grep -v grep | grep -v tail  | grep -v cat | awk {'print $4'})
		if [ "$pintura_ui_state" == "D" ]
		then
			pinturaUIDownCount=$(($pinturaUIDownCount+1))
			if [ $pinturaUIDownCount -eq 20 ]
			then
				pinturaUIDownCount=0;
				grace_reboot "top -n1 catch pintura_ui_state D status over 20 times"
			fi
		else
			pinturaUIDownCount=0;
		fi
	fi

    sleep 1
done
