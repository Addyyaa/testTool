#!/bin/sh

daemon_log=/software/script/log_dump.sh
script_name=$(basename "$0")
$daemon_log "$script_name: restart remote"

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/lib:/config/lib:/customer/lib:/customer/bluetooth/lib:/software/lib:/software/bin:/software/bin/pintura/release/bin:upgrade/lib:/config/wifi:/software/qrcode

kill -9 $(pidof rtl_gatts)
sleep 0.5

cd /customer/bluetooth/bin/
./hciconfig hci0 down
./hciconfig hci0 up
./hciconfig hci0 piscan

cd /software/bin/
./ble_remote &

if [ "$1" == "notip" ];
then
echo "remote_on no tip"
else
echo "remote_on" > /tmp/tip_status
fi

sync

