#!/bin/sh

daemon_log=/software/script/log_dump.sh
script_name=$(basename "$0")
$daemon_log "$script_name: clear picture"

rm /customer/video/*tmp
if [ -e /mnt/video/ ]; then
	rm /mnt/video/*tmp
fi

# if pidof wget > /dev/null; then
# 	kill -9 $(pidof wget);
# fi

if [ -e /customer/picture_cache ]; then	
	timestamp=$(date +%s)	
	mv /customer/picture_cache /customer/picture_cache_trash_$timestamp
	mkdir -p /customer/picture_cache/
	rm -rf /customer/picture_cache_trash_$timestamp &	
fi

if [ -e /mnt/picture/ ]; then
	timestamp=$(date +%s)	
	mv /mnt/picture /mnt/picture_trash_$timestamp
	mkdir -p /mnt/picture/
	rm -rf /mnt/picture_trash_$timestamp &
fi

if [ -e /customer/picture/ ]; then
	timestamp=$(date +%s)	
	mv /customer/picture /customer/picture_trash_$timestamp
	mkdir -p /customer/picture/
	rm -rf /customer/picture_trash_$timestamp &
fi

