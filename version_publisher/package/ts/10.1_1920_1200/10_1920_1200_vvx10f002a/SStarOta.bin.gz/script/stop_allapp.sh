#!/bin/sh

daemon_log=/software/script/log_dump.sh
script_name=$(basename "$0")
$daemon_log "$script_name: stop allapp"

kill -9 $(pgrep -f daemon.sh)
kill -9 $(pgrep -f misc_driver)
kill -9 $(pidof mymqtt) 
kill -9 $(pidof pintura)
kill -9 $(pidof video_player)
kill -9 $(pidof screen_driver)
kill -9 $(pidof rtl_gatts) 
kill -9 $(pidof uart_main) 
kill -9 $(pidof crond) 
kill -9 $(pidof ntpd)
kill -9 $(pidof wpa_supplicant)
kill -9 $(pidof udhcpc)

