#!/bin/sh

script_name=$(basename "$0")
logName="/customer/logs/daemon.log"  # log path
let maxsize=5*1024*1024 			# 1 MB
printTime=$(date +%Y-%m%dT%H:%M:%S)

echo "$script_name $printTime $1"
if [ -e $logName ]; then
	filesize=`ls -l $logName |awk '{print $5}'`
	if [ "$filesize" -ge "$maxsize" ]
	then
		echo > $logName
	fi
fi

echo -e "$script_name $printTime $1 \n" >> $logName
free >> $logName

