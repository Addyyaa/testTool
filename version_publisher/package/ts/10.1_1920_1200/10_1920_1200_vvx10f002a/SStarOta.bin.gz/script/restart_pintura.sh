#!/bin/sh

daemon_log=/software/script/log_dump.sh
script_name=$(basename "$0")
$daemon_log "$script_name: restart pintura"

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/lib:/config/lib:/customer/lib:/customer/bluetooth/lib:/software/bin/pintura/release/bin:/software/lib:/upgrade/lib:/config/wifi:/software/qrcode

LOCKFILE=/tmp/demo.lock

{
	echo 'restart pintura'
	if [ "`grep off /tmp/screen_on_off`" != ""  ]; then
		echo "screen is off"
		exit 0
	fi

	find /tmp -type f -name "*.lock" -not -name "demo.lock" -delete
	
    # get lock
    flock -n 200
    if [ $? -ne 0 ]; then
		if [ "`pidof pintura`" != "" ]
		then
			kill -9 $(pidof pintura)
			rm /tmp/*.lock
		elif [ "`pidof screen_driver`" != "" ] && [ "`pidof pintura`" == "" ]
		then
			echo "screen_driver is running, but demo is not running, remove /tmp/demo.lock."
			if [ -e /tmp/demo.lock ]
			then
				rm /tmp/demo.lock
			fi
		else
			echo "Another instance of the script is running. Exiting."
			exit 1
		fi
    fi	


	echo "kill screen_driver start..."
	cat /proc/mi_modules/mi_sys_mma/mma_heap_name0;


	if [ "`pidof screen_driver`" != "" ]; then

		cd /software/bin/
		./kill_screen_driver &
		#kill -9 $(pidof screen_driver);	
		if [ "`pidof screen_driver`" != "" ]; then
			count=0
			while [ "$count" != "30"  ]
			do
				if [ "`pidof screen_driver`" == "" ]; then
					break
				fi
				count=$(($count+1))
				if [ "$count" == "30"  ]; then
					kill -9 $(pidof screen_driver);
					sleep 1;
					break;
				fi
				sleep 0.1
			done
			
			sleep 0.1
		fi
	fi

    # run screen_driver command
	echo "boot screen_driver start"
	cat /proc/mi_modules/mi_sys_mma/mma_heap_name0;

	if [ "`pidof screen_driver`" == "" ] && ([ ! -e /tmp/screen_on_off ] || [ "`grep off /tmp/screen_on_off`" == "" ]); then

		echo "boot screen_driver start"
		cd /software/bin/
		./screen_driver &

		count=0
		while [ "$count" != "20"  ]
		do
			if [ "`pidof screen_driver`" != "" ]; then
				break
			fi
			count=$(($count+1))
			sleep 0.1
		done
		sleep 0.1

		echo "boot screen_driver over"
	fi


    # run pintura command
	echo "boot pintura start"
	cat /proc/mi_modules/mi_sys_mma/mma_heap_name0;

    if [ "`pidof pintura`" == "" ] && [ "`pidof screen_driver`" != "" ] && [ "`pidof video_player`" != "" ]; then

		echo "boot pintura start"
		cd /software/pintura/release/bin
		./pintura &

		count=0
		while [ "$count" != "20"  ]
		do
			if [ "`pidof pintura`" != "" ]; then
				break
			fi
			count=$(($count+1))
			sleep 0.1
		done
		sleep 0.1

		echo "boot pintura over"
    fi
	
} 200>$LOCKFILE
