###########################################################################################
# This script is executed only after the old version is restarted.
# So the script is used to handle the upgrade from the old version to the new version.
############################################################################################

VERSION_PATH=/software/version.ini
section="version"
key="sversion"

if [ -e $VERSION_PATH ]
then
    # process fot newer version
    echo "find $VERSION_PATH, try upgrading"

    VERSION_NUMBER=$(awk -F "=" -v section="$section" -v key="$key" '$1 ~ /^\[/ && $1 ~ section {flag=1; next} flag==1 && $1 ~ /^\[/ {flag=0} flag==1 && $1 ~ key {print $2}' "$VERSION_PATH")
    echo "VERSION_NUMBER.orig:${VERSION_NUMBER}"

    VERSION_NUMBER=$(echo $VERSION_NUMBER | tr -d '.')
    echo "VERSION_NUMBER.trip:${VERSION_NUMBER}"

    if [ $VERSION_NUMBER -gt '200000' ]
    then
        echo "lower fireware upgrading fireware"
        cp /software/script/demo.sh /customer/

        # Except for screenId.ini
        mkdir -p /customer/config/
        mv /customer/config.ini               /customer/config/
        mv /customer/groupId.ini              /customer/config/
        mv /customer/color_temper_config.ini  /customer/config/
        mv /customer/image_config.ini         /customer/config/
        mv /customer/luma_config.ini          /customer/config/
        mv /customer/volume.ini               /customer/config/
        mv /customer/local_time_zone.ini      /customer/config/

        mv /customer/picture_config.ini       /customer/config/
        mv /customer/picture_total_config.ini /customer/config/
        mv /customer/video_config.ini         /customer/config/
        mv /customer/video_total_config.ini   /customer/config/

        ## If upgrade from a lower version to a higher version, retain the data of the old version to prevent a reset later
        # rm -rf /customer/bluetooth_on
        # rm -rf /customer/screen_on_off

        # rm -rf /upgrade/JpegPlayer
        # rm -rf /upgrade/ota_view
        # rm -rf /upgrade/daemon.sh
        # rm -rf /upgrade/local.ini
        # rm -rf /upgrade/ota_launcher
        # rm -rf /upgrade/ota_status
        # rm -rf /upgrade/otaunpack
        # rm -rf /upgrade/reset_status
        # rm -rf /upgrade/restart_ota_down_view.sh
        # rm -rf /upgrade/restart_reset_view.sh
        # rm -rf /upgrade/restore_factory_settings.sh
        # rm -rf /upgrade/upgrade.sh

        echo high > /sys/class/gpio/gpio5/direction;
        sleep 0.1
        if [ ! -e /sys/class/gpio/gpio48/value ]
        then				
            echo 48 > /sys/class/gpio/export				
        fi
        if [ -e /sys/class/gpio/gpio48/value ]
        then
            echo low > /sys/class/gpio/gpio48/direction
        fi

        rm -rf /software/software_init.sh
        sync
        reboot
    fi
fi
