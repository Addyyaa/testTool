#!/bin/sh

section="version"
key="sversion"
VERSION_PATH=/software/version.ini
if [ -e $VERSION_PATH ]
then
    VERSION_NUMBER=$(awk -F "=" -v section="$section" -v key="$key" '$1 ~ /^\[/ && $1 ~ section {flag=1; next} flag==1 && $1 ~ /^\[/ {flag=0} flag==1 && $1 ~ key {print $2}' "$VERSION_PATH")
    VERSION_NUMBER=$(echo $VERSION_NUMBER | tr -d '.')
    echo "VERSION_NUMBER.trip:${VERSION_NUMBER}"

    if [ $VERSION_NUMBER -lt '200000' ]
    then
        echo "ota: downgrading fireware !!!"

        cp /software/demo.sh                             /customer/
		mv /customer/config/config.ini                   /customer/
		mv /customer/config/color_temper_config.ini      /customer/
		mv /customer/config/luma_config.ini              /customer/
		mv /customer/config/image_config.ini             /customer/
		mv /customer/config/groupId.ini                  /customer/
		mv /customer/config/volume.ini                   /customer/

		mv /customer/config/video_config.ini            /customer/
		mv /customer/config/video_total_config.ini      /customer/
		mv /customer/config/picture_config.ini          /customer/
		mv /customer/config/picture_total_config.ini    /customer/
		rm -rf /customer/config/

		cp -rf /software/ota_view/                                      /upgrade/
		cp -rf /software/pintura/release/bin/*.so                       /upgrade/ota_view/release/bin/
		cp -rf /software/pintura/release/assets/default/raw/fonts/*     /upgrade/ota_view/release/assets/default/raw/fonts/
		cp -rf /software/daemon.sh/                                     /upgrade/

        sync
    fi
fi