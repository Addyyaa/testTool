#!/bin/sh
pressTimeCount=0
pressTime=0

normalCheckCount=0
msicAbnormalCount=0
screenAbnormalCount=0
videoAbnormalCount=0
pinturaAbnormalCount=0

startTime=$(date +%s)

while [ 1 ]
    do
    sleep 1

	if [ "`pidof misc_driver`" == "" ]; then
		echo "recovery:abnormal startup, misc driver is not running"
		msicAbnormalCount=$(($msicAbnormalCount+1))
	fi

	if [ "`pidof screen_driver`" == "" ]; then
		echo "recovery:abnormal startup, screen driver is not running"
		screenAbnormalCount=$(($screenAbnormalCount+1))
	fi

	if [ "`pidof video_player`" == "" ]; then
		echo "recovery:abnormal startup, video player is not running"
		videoAbnormalCount=$(($videoAbnormalCount+1))
	fi

	if [ "`pidof pintura`" == "" ]; then
		echo "recovery:abnormal startup, pintura ui is not running"
		pinturaAbnormalCount=$(($pinturaAbnormalCount+1))
	fi

	echo -e "---------------------------------------------\n"

	normalCheckCount=$(($normalCheckCount+1))
	if [ $normalCheckCount -gt 15 ]; then
		echo "recovery:check timeout..."
		break
	fi
done

echo "recovery:msicAbnormalCount=$msicAbnormalCount"
echo "recovery:screenAbnormalCount=$screenAbnormalCount"
echo "recovery:videoAbnormalCount=$videoAbnormalCount"
echo "recovery:pinturaAbnormalCount=$pinturaAbnormalCount"

if [ $msicAbnormalCount -eq 0 ] && [ $screenAbnormalCount -eq 0 ] && [ $videoAbnormalCount -eq 0 ] && [ $pinturaAbnormalCount -eq 0 ]; then
	echo "recovery:normal system startup, exit recovery mode"
	exit 0;
fi

echo "recovery:abnormal startup, carry the data back to the factory"

cp /upgrade/restore/SStarOta.bin.gz /upgrade/
if [ -e /upgrade/restore/rst_md5 ]; then
	cp /upgrade/restore/rst_md5 /upgrade/ota_md5
else
	cd /upgrade/
	md5sum SStarOta.bin.gz > ota_md5
fi

touch /upgrade/recovery.flag
/upgrade/recovery/upgrade.sh



