#!/bin/sh
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/lib:/config/lib:/customer/lib:/customer/bluetooth/lib:/software/lib:/software/bin:/software/bin/pintura/release/bin:upgrade/lib:/config/wifi:/software/qrcode
script_name=$(basename "$0")

wlanDownCount=0
pinturaUIDownCount=0
videoPlayerDownCount=0
pairing_status='';
ble_state=0;
ble_state_update_time=0;
ble_state_count=0
ble_adv_count=0
daemon_log=/software/script/log_dump.sh


scr_init_on=1
if [ "`grep off /tmp/screen_on_off`" != ""  ]; then
	echo "screen is off"
	scr_init_on=0
else
	echo "screen is on"
fi

if [ scr_init_on == 0 ]; then
	$daemon_log "$script_name: wakeup screen"
	nohup /software/script/wakeup.sh >/dev/null &
    sleep 60
fi

while [ 1 ]
do
	$daemon_log "$script_name: sleep screen"
	nohup /software/script/sleep.sh >/dev/null &
    sleep 60

	$daemon_log "$script_name: wakeup screen"
	nohup /software/script/wakeup.sh >/dev/null &
	sleep 60
done
