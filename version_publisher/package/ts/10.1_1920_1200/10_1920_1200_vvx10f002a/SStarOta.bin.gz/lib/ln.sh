current_path=$(pwd)
cd $current_path

## jpeg
if [ -f "$current_path/libjpeg.so" ] && [ ! -f "$current_path/libjpeg.so.7" ]; then
	ln -s libjpeg.so libjpeg.so.7
fi

if [ -f "$current_path/libjpeg.so" ] && [ ! -f "$current_path/libjpeg.so.7.0.0" ]; then
	ln -s libjpeg.so libjpeg.so.7.0.0
fi

## libz
if [ -f "$current_path/libz.so" ] && [ ! -f "$current_path/libz.so.1" ]; then
	ln -s libz.so libz.so.1
fi

if [ -f "$current_path/libz.so" ] && [ ! -f "$current_path/libz.so.1.2.2" ]; then
	ln -s libz.so libz.so.1.2.2
fi

## libssl
if [ -f "$current_path/libssl.so" ] && [ ! -f "$current_path/libssl.so.1.0.0" ]; then
	ln -s libssl.so libssl.so.1.0.0
fi

## zlog
if [ -f "$current_path/libzlog.so" ] && [ ! -f "$current_path/libzlog.so.1" ]; then
	ln -s libzlog.so libzlog.so.1
fi

if [ -f "$current_path/libzlog.so" ] && [ ! -f "$current_path/libzlog.so.1.2" ]; then
	ln -s libzlog.so libzlog.so.1.2
fi

## log4c
if [ -f "$current_path/liblog4c.so" ] && [ ! -f "$current_path/liblog4c.so.3" ]; then
	ln -s liblog4c.so liblog4c.so.3
fi

if [ -f "$current_path/liblog4c.so" ] && [ ! -f "$current_path/liblog4c.so.3.3.1" ]; then
	ln -s liblog4c.so liblog4c.so.3.3.1
fi

## ffmpeg
if [ -f "$current_path/libavcodec.so" ] && [ ! -f "$current_path/libavcodec.so.58" ]; then
	ln -s libavcodec.so libavcodec.so.58
fi

if [ -f "$current_path/libavformat.so" ] && [ ! -f "$current_path/libavformat.so.58" ]; then
	ln -s libavformat.so libavformat.so.58
fi

if [ -f "$current_path/libavutil.so" ] && [ ! -f "$current_path/libavutil.so.56" ]; then
	ln -s libavutil.so libavutil.so.56
fi

if [ -f "$current_path/libswresample.so" ] && [ ! -f "$current_path/libswresample.so.3" ]; then
	ln -s libswresample.so libswresample.so.3
fi

if [ -f "$current_path/libswscale.so" ] && [ ! -f "$current_path/libswscale.so.5" ]; then
	ln -s libswscale.so libswscale.so.5
fi